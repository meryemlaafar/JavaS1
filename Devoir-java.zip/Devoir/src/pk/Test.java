package pk;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		Joueur joueur1 = new Joueur("Entraineur1", "Equipe1", 1, "Joueur1", null);
        Joueur joueur2 = new Joueur("Entraineur2", "Equipe2", 2, "Joueur2", null);
        Joueur joueur3 = new Joueur("Entraineur3", "Equipe3", 3, "Joueur3", null);
        
        EquipeFoot[] e3= new EquipeFoot[3];

        Entraineur e1 = new Entraineur("entraineur1","equipe3",124,e3);
        System.out.println("remplire votre tableau");
        e1.remplire();
        System.out.println("avant le tri");
        e1.afficherElements();
        /*e1.ajouter(0, joueur1);
        System.out.println("apres l'ajout du joueur: ");
        e1.afficherElements();*/
        EquipeFoot equipeTest = new EquipeFoot("Entraineur2", "Equipe2", 2);
        System.out.println("L'équipe existe : " + e1.existe(equipeTest));

        e1.supprimer(equipeTest);

        // Afficher les éléments après la suppression
        System.out.println("Après la suppression de l'équipe 2 :");
        e1.afficherElements();
        
        MembreStaff membreStaff = new MembreStaff();

     // Création d'équipes
     EquipeFoot equipe1 = new EquipeFoot("Entraineur1", "Equipe1", 1);
     EquipeFoot equipe2 = new EquipeFoot("Entraineur2", "Equipe2", 2);
     EquipeFoot equipe3 = new EquipeFoot("Entraineur3", "Equipe3", 3);

     // Alimentation de la liste avec les équipes
     membreStaff.alimenterListe(equipe1);
     membreStaff.alimenterListe(equipe2);
     membreStaff.alimenterListe(equipe3);

        // Affichage de la liste initiale
        System.out.println("Liste initiale :");
        membreStaff.afficherListe();

        // Trier la liste
        membreStaff.trierListe();
        System.out.println("Liste triée :");
        membreStaff.afficherListe();

        // Mélanger la liste
        membreStaff.melangerListe();
        System.out.println("Liste mélangée :");
        membreStaff.afficherListe();

        // Inverser la liste
        membreStaff.inverserListe();
        System.out.println("Liste inversée :");
        membreStaff.afficherListe();

        // Extraire une partie de la liste
        List<EquipeFoot> partieListe = membreStaff.extrairePartieListe(1, 2);
        System.out.println("Partie extraite de la liste :");
        for (EquipeFoot equipe : partieListe) {
            System.out.println(equipe);
        }

        // Échanger deux éléments dans la liste
        membreStaff.echangerElements(0, 2);
        System.out.println("Liste après échange d'éléments :");
        membreStaff.afficherListe();

        // Vider la liste
        membreStaff.viderListe();
        System.out.println("Liste après vidage :");
        membreStaff.afficherListe();

        // Tester si la liste est vide
        System.out.println("verifier si la liste est vide : " + membreStaff.estVide());
    }


	}


