package pk;

import java.util.List;
import java.util.Objects;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;  // Ajout de l'import pour Iterator

public class MembreStaff {
    private List<EquipeFoot> equipeList;

    // Constructeur
    public MembreStaff() {
        equipeList = new ArrayList<>();
    }

    // Méthode qui permet d'alimenter la liste
    public void alimenterListe(EquipeFoot equipe) {
        equipeList.add(equipe);
    }

    // Méthode qui permet d'afficher la liste (ligne par ligne)
    public void afficherListe() {
        System.out.println("Les éléments de la liste :");
        for (EquipeFoot equipe : equipeList) {
            System.out.println(equipe);
        }
    }
    public void parcourirListe() {
        Iterator<EquipeFoot> iterator = equipeList.iterator();
        while (iterator.hasNext()) {
            EquipeFoot equipe = iterator.next();
            // Faire quelque chose avec chaque équipe, par exemple, l'afficher
            System.out.println(equipe);
        }
    }
 // Méthode qui permet d'insérer un élément dans la liste
    public void insererElement(int index, EquipeFoot equipe) {
        if (index >= 0 && index <= equipeList.size()) {
            equipeList.add(index, equipe);
        } else {
            throw new IllegalArgumentException("Veuillez insérer une position valide");
        }
    }
 // Méthode qui permet de récupérer un élément de la liste
    public EquipeFoot recupererElement(int index) {
        if (index >= 0 && index < equipeList.size()) {
            return equipeList.get(index);
        } else {
            throw new IllegalArgumentException("Veuillez spécifier une position valide");
        }
    }
 // Méthode qui permet de supprimer un élément de la liste
    public boolean supprimerElement(EquipeFoot equipe) {
        return equipeList.remove(equipe);
    }
 // Méthode qui permet de rechercher un élément dans la liste
    public boolean rechercherElement(EquipeFoot equipe) {
        return equipeList.contains(equipe);
    }
    public void trierListe() {
        Collections.sort(equipeList);
    }
    public EquipeFoot[] copierListeVersTableau() {
        return equipeList.toArray(new EquipeFoot[equipeList.size()]);
    }
    public void melangerListe() {
        Collections.shuffle(equipeList);
    }
    public void inverserListe() {
        Collections.reverse(equipeList);
    }
    public List<EquipeFoot> extrairePartieListe(int debut, int fin) {
        if (debut >= 0 && fin <= equipeList.size() && debut <= fin) {
            return equipeList.subList(debut, fin);
        } else {
            throw new IllegalArgumentException("Veuillez spécifier des indices valides");
        }
    }
 // Méthode qui permet de comparer deux listes
    public boolean comparerListes(List<EquipeFoot> autreListe) {
        // Comparaison des listes en utilisant la méthode equals
        return Objects.equals(equipeList, autreListe);
    }
 // Méthode qui permet d'échanger deux éléments dans la liste
    public void echangerElements(int indice1, int indice2) {
        if (indice1 >= 0 && indice1 < equipeList.size() && indice2 >= 0 && indice2 < equipeList.size()) {
            // Utilisation de Collections.swap pour échanger les éléments aux indices spécifiés
            Collections.swap(equipeList, indice1, indice2);
        } else {
            throw new IllegalArgumentException("Veuillez spécifier des indices valides");
        }
    }
 // Méthode qui permet de vider la liste
    public void viderListe() {
        equipeList.clear();
    }
    // Méthode qui permet de tester si la liste est vide
    public boolean estVide() {
        return equipeList.isEmpty();
    }

    // Autres méthodes de manipulation de la liste peuvent être ajoutées selon vos besoins
}
